package com.watersort.autobot

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityService.ScreenshotResult
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.util.Log

/**
 * Accessibility bridge. This first build deliberately does not tap guessed coordinates.
 * Screen parsing must be validated against the exact game UI before unattended play is enabled.
 */
class BotAccessibilityService : AccessibilityService() {
    companion object {
        @Volatile var instance: BotAccessibilityService? = null
    }

    private val handler = Handler(Looper.getMainLooper())
    private var lastReport = 0L

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        Log.i("WaterSortBot", "Accessibility service connected")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) { }
    override fun onInterrupt() { }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    fun captureScreen(onResult: (Bitmap?) -> Unit) {
        if (android.os.Build.VERSION.SDK_INT < 30) {
            onResult(null)
            return
        }
        takeScreenshot(
            android.view.Display.DEFAULT_DISPLAY,
            mainExecutor,
            object : TakeScreenshotCallback {
                override fun onSuccess(result: ScreenshotResult) {
                    val hardware = result.hardwareBuffer
                    val bitmap = Bitmap.wrapHardwareBuffer(hardware, result.colorSpace)
                    hardware.close()
                    onResult(bitmap?.copy(Bitmap.Config.ARGB_8888, false))
                }

                override fun onFailure(errorCode: Int) {
                    Log.e("WaterSortBot", "Screenshot failed: $errorCode")
                    onResult(null)
                }
            }
        )
    }

    fun tap(x: Float, y: Float, onFinished: (() -> Unit)? = null) {
        val path = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(path, 0, 90)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) { onFinished?.invoke() }
            override fun onCancelled(gestureDescription: GestureDescription?) { onFinished?.invoke() }
        }, null)
    }

    fun diagnosticCapture() {
        captureScreen { bitmap ->
            if (bitmap == null) return@captureScreen
            Log.i("WaterSortBot", "Captured ${bitmap.width}x${bitmap.height} screen")
            bitmap.recycle()
        }
    }
}
