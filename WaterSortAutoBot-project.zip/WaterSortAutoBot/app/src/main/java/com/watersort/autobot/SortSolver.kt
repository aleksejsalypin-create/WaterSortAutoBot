package com.watersort.autobot

/**
 * Exact state-space solver for classic Water Sort.
 * Each tube is bottom-to-top; null/empty slots are not stored.
 * A move pours the maximal contiguous top run into an empty tube or a tube
 * whose top color matches, subject to capacity.
 */
object SortSolver {
    data class Move(val from: Int, val to: Int)
    private data class Node(val state: List<String>, val path: List<Move>)

    fun solve(start: List<List<String>>, capacity: Int = 4, maxVisited: Int = 500_000): List<Move>? {
        val initial = start.map { it.toList() }
        val queue = ArrayDeque<Node>()
        val seen = HashSet<String>()
        queue.add(Node(initial, emptyList()))
        seen.add(key(initial))

        var visited = 0
        while (queue.isNotEmpty() && visited < maxVisited) {
            val node = queue.removeFirst()
            visited++
            if (isSolved(node.state, capacity)) return node.path

            for (from in node.state.indices) {
                val source = node.state[from]
                if (source.isEmpty()) continue
                if (source.size == capacity && source.distinct().size == 1) continue

                val color = source.last()
                var run = 1
                for (i in source.size - 2 downTo 0) {
                    if (source[i] == color) run++ else break
                }

                for (to in node.state.indices) {
                    if (to == from) continue
                    val dest = node.state[to]
                    if (dest.size >= capacity) continue
                    if (dest.isNotEmpty() && dest.last() != color) continue
                    if (dest.isEmpty() && source.all { it == color }) continue

                    val amount = minOf(run, capacity - dest.size)
                    val next = node.state.map { it.toMutableList() }.toMutableList()
                    repeat(amount) { next[from].removeAt(next[from].lastIndex) }
                    repeat(amount) { next[to].add(color) }
                    val immutable = next.map { it.toList() }
                    val k = key(immutable)
                    if (seen.add(k)) queue.add(Node(immutable, node.path + Move(from, to)))
                }
            }
        }
        return null
    }

    private fun isSolved(state: List<List<String>>, capacity: Int): Boolean =
        state.all { it.isEmpty() || (it.size == capacity && it.distinct().size == 1) }

    private fun key(state: List<List<String>>): String =
        state.joinToString("|") { it.joinToString(",") }
}
