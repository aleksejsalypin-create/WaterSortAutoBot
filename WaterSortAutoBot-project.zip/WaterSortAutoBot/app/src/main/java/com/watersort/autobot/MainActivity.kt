package com.watersort.autobot

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 48, 36, 36)
            gravity = Gravity.CENTER_HORIZONTAL
        }
        val title = TextView(this).apply {
            text = "Water Sort AutoBot"
            textSize = 26f
        }
        status = TextView(this).apply {
            textSize = 16f
            text = "Шаг 1. Разреши специальную возможность управления экраном."
            setPadding(0, 28, 0, 28)
        }
        val settings = Button(this).apply {
            text = "Открыть настройки специальных возможностей"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        val test = Button(this).apply {
            text = "Проверить подключение"
            setOnClickListener {
                val enabled = BotAccessibilityService.instance != null
                status.text = if (enabled)
                    "Сервис подключён. Следующий этап — проверка распознавания колб."
                else
                    "Сервис пока не включён. Найди Water Sort AutoBot в специальных возможностях и включи его."
            }
        }
        val stop = Button(this).apply {
            text = "Остановить бота"
            setOnClickListener {
                getSharedPreferences("bot", MODE_PRIVATE).edit().putBoolean("running", false).apply()
                status.text = "Автоматизация остановлена."
            }
        }
        layout.addView(title)
        layout.addView(status)
        layout.addView(settings)
        layout.addView(test)
        layout.addView(stop)
        setContentView(layout)
    }
}
