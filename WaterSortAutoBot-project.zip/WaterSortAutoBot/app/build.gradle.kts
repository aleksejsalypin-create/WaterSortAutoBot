plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.watersort.autobot"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.watersort.autobot"
        minSdk = 30
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.0"
    }
}
