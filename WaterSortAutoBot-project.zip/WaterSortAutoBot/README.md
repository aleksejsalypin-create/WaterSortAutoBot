# Water Sort AutoBot — Android starter project

This is the first buildable Android project for a Water Sort automation assistant.

## What is included
- Android AccessibilityService declaration with screenshot and gesture capabilities.
- Screen capture bridge and safe tap primitive.
- A breadth-first solver for classic four-layer Water Sort states.
- GitHub Actions workflow that builds a debug APK and publishes it as an artifact.

## Important status
This is **not yet a fully autonomous game-playing bot**. The visual detector for the exact
Water Sort Master 3D screen, level/menu state machine, and verified move execution are not
implemented yet. The service intentionally does not tap guessed coordinates. Those pieces
must be calibrated and tested against real screenshots before unattended play is safe.

## Build APK with GitHub
1. Create a new GitHub repository.
2. Upload the contents of this folder to the repository root (not the ZIP itself).
3. Open the **Actions** tab and run **Build Android APK** (or push to `main`).
4. Open the successful workflow run and download artifact `WaterSortAutoBot-debug`.
5. Extract the artifact and install `app-debug.apk` on the Realme.

## Enable the accessibility service
After installing, open Water Sort AutoBot → "Открыть настройки специальных возможностей" →
enable "Water Sort AutoBot control". Android will show a system warning because this service
can observe the screen and perform gestures. Enable it only for this app and only if you trust
the APK you installed.

## Next development milestone
Capture representative screenshots for:
- an active puzzle,
- the win/result screen,
- the main menu with the next-level button.

Then implement and validate tube geometry/color segmentation and the game state machine.
